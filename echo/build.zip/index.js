exports.handler = function (event) {
	console.log('hello world');
};